  Theme Name: Flooring
  Theme URI: http://themes.webdevia.com/flooring/
  Description: Flooring company WordPress theme
  Author: Mymoun
  Author URI: http://www.webdevia.com/
  Version: 4.5.1
  Text Domain: flooring
  Domain Path: /languages