<?php
// Instantiate the class
if ( class_exists('flooring_myCustomFields') ) {
	$flooring_myCustomFields_var = new flooring_myCustomFields();
}