<article class="post">
	<div class="quote-format">
		<blockquote>
			<span class="leftq quotes">&#xf0c1;</span>

				<p><a href="#" title="Home"><?php the_content() ?></a></p>

					<div class="share-post">
						<span class="left"><i class="fa fa-share-alt"></i></span>
								<div data-title="&lt;i class='fa fa-twitter'&gt;&lt;/i&gt;"
								     data-text="We are happy to announce that negotiation Etiam diam augue" data-url="#"
								     class="twitter-share left sharrre">
									<div class="box"><a href="#" class="count">0</a><a href="#" class="share"><i
												class="fa fa-twitter"></i></a></div>
								</div>
								<div data-title="&lt;i class='fa fa-facebook'&gt;&lt;/i&gt;"
								     data-text="We are happy to announce that negotiation Etiam diam augue" data-url="#"
								     class="facebook-share left sharrre">
									<div class="box"><a href="#" class="count">0</a><a href="#" class="share"><i
												class="fa fa-facebook"></i></a></div>
								</div>
							</div>
						</blockquote>
					</div>
				</article>