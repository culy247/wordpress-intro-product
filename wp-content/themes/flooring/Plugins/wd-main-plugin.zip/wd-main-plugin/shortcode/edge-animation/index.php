<div class="">
<div id="Stage" class="wd-benefits EDGE-152523965">
		<div id="Stage_static-svg2" class="edgeLoad-EDGE-152523965"></div>
    <div id="Stage_cloud3" class="edgeLoad-EDGE-152523965"></div>
    <div id="Stage_cloud2" class="edgeLoad-EDGE-152523965"></div>
    <div id="Stage_cloud12" class="edgeLoad-EDGE-152523965"></div>
    <div id="Stage_turbon15" class="edgeLoad-EDGE-152523965"></div>
    <div id="Stage_turbon23" class="edgeLoad-EDGE-152523965"></div>
    <div id="Stage_turbon33" class="edgeLoad-EDGE-152523965"></div>
    <div id="Stage_sun" class="edgeLoad-EDGE-152523965"></div>
</div>
</div>
<?php $url = plugins_url(); ?>

<script type="text/javascript" src="<?php echo plugins_url() . '/wd-main-plugin/shortcode/edge-animation/svg%20edge_edgePreload.js'; ?>"></script>
